import "@hotwired/turbo-rails"; // Turbo Drive for partial page updates and navigation
import "controllers"; // Import all controllers
import "bootstrap"; // Import Bootstrap for UI components
import "@popperjs/core"; // Import Popper.js for dropdowns, tooltips, popovers;
